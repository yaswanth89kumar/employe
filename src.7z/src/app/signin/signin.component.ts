import { Component, OnInit } from '@angular/core';
import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { SigninService } from '../signin/signin.service';

@Injectable()
@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {
    
 private profile ="";
username: string = "";
password: string = "";

  constructor(private signinservice: SigninService) { }

  ngOnInit() {
  }
    
  getUser() {
    this.signinservice.getUser(this.username, this.password).subscribe(data => this.profile = data);
  }


}
